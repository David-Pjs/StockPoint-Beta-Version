import { useEffect, useMemo, useState } from "react";
import Card from "../../ui/Card";
import Pill from "../../ui/Pill";
import {
  getTransactionsForDay,
  getTransactionsForMonth,
  getSales,
  getSaleItems,
  setPaidFlag,
  getPaidMap,
  deleteTransaction,
  money,
  type Transaction,
  type Sale,
  type SaleItem,
} from "../../index";

/* ---------------- time helpers (local, no UTC drift) ---------------- */
function todayYMD(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
function monthKeyFromYMD(ymd: string) { return ymd.slice(0, 7); } // YYYY-MM
function addDays(ymd: string, delta: number) {
  const [y,m,d] = ymd.split("-").map(Number);
  const dt = new Date(y, m-1, d); dt.setDate(dt.getDate() + delta);
  const yy = dt.getFullYear();
  const mm = String(dt.getMonth()+1).padStart(2,"0");
  const dd = String(dt.getDate()).padStart(2,"0");
  return `${yy}-${mm}-${dd}`;
}
function daysInMonth(y: number, m: number) { return new Date(y, m, 0).getDate(); }

/* ---------------- tiny viz + csv helpers ---------------- */
function SparkBars({ series, height = 36, title }: { series: number[]; height?: number; title?: string }) {
  const max = Math.max(1, ...series);
  return (
    <div>
      {title && <div className="mb-1 text-xs muted">{title}</div>}
      <div className="flex items-end gap-[6px]" style={{ height }}>
        {series.map((v, i) => (
          <div key={i} className="rounded bg-[#1a2944]" style={{ height: `${(v / max) * 100}%`, width: "10px" }} />
        ))}
      </div>
    </div>
  );
}
function downloadCSV(filename: string, rows: (string|number)[][]) {
  const esc = (s: string|number) => {
    const str = String(s ?? "");
    return /[",\n]/.test(str) ? `"${str.replace(/"/g,'""')}"` : str;
  };
  const csv = rows.map(r => r.map(esc).join(",")).join("\n");
  const blob = new Blob([csv], { type:"text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

/* ---------------- types & state keys ---------------- */
type RangeKey = "today" | "7d" | "month" | "custom";

type DayRow = {
  date: string;
  income: number;
  expense: number;
  net: number;
  orders: number;
  items: number;
  discounts: number;
  aov: number;
};

export default function ReportsPage() {
  /* -------- range + options -------- */
  const [range, setRange] = useState<RangeKey>("today");
  const [dayDate, setDayDate] = useState<string>(todayYMD());
  const [monthKey, setMonthKey] = useState<string>(monthKeyFromYMD(todayYMD()));
  const [startDate, setStartDate] = useState<string>(addDays(todayYMD(), -6));
  const [endDate, setEndDate] = useState<string>(todayYMD());
  const [includeQuickTx, setIncludeQuickTx] = useState(true);

  /* -------- realtime pulse (cross-tab) -------- */
  const [pulse, setPulse] = useState(0);
  useEffect(() => {
    const onStorage = (e: StorageEvent) => { if (e.key === "__sp_changed__") setPulse(p => p+1); };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  /* -------- paid map for actions -------- */
  const [paidMap, setPaidMapState] = useState<Record<string, boolean>>(() => getPaidMap());
  function refreshPaid() { setPaidMapState({ ...getPaidMap() }); }

  /* -------- date list for selected range -------- */
  const dates = useMemo(() => {
    if (range === "today") return [dayDate];
    if (range === "7d") return Array.from({length:7}, (_,i)=> addDays(dayDate, -6 + i));
    if (range === "month") {
      const [y,m] = monthKey.split("-").map(Number);
      const n = daysInMonth(y, m);
      return Array.from({length:n}, (_,i)=> `${monthKey}-${String(i+1).padStart(2,"0")}`);
    }
    // custom
    const out: string[] = [];
    let d = startDate;
    while (d <= endDate) { out.push(d); d = addDays(d, 1); }
    return out;
  }, [range, dayDate, monthKey, startDate, endDate]);

  /* -------- raw data pulls (minimal calls, then filter) -------- */
  // Sales: we can grab all and filter by date set.
  const allSales = useMemo(() => getSales(), [pulse]);
  const allItems = useMemo(() => getSaleItems(), [pulse]);

  // Transactions: for month use month API, for others use per-day.
  const txByDate: Record<string, Transaction[]> = useMemo(() => {
    if (range === "month") {
      const monthTx = getTransactionsForMonth(monthKey);
      const map: Record<string, Transaction[]> = {};
      for (const d of dates) map[d] = [];
      for (const t of monthTx) { if (map[t.occurred_on]) map[t.occurred_on].push(t); }
      return map;
    } else {
      const map: Record<string, Transaction[]> = {};
      for (const d of dates) map[d] = getTransactionsForDay(d);
      return map;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [range, monthKey, dates, pulse]);

  /* -------- per-day series & totals -------- */
  const daySeries: DayRow[] = useMemo(() => {
    const dateSet = new Set(dates);
    const salesByDate = new Map<string, Sale[]>();
    dates.forEach(d => salesByDate.set(d, []));
    allSales.forEach(s => { if (dateSet.has(s.sold_on)) salesByDate.get(s.sold_on)!.push(s); });

    return dates.map(d => {
      const txs = txByDate[d] || [];
      const sales = salesByDate.get(d) || [];
      const orders = sales.length;
      const itemsCount = allItems.reduce((sum, it) => (sales.find(s => s.id === it.sale_id) ? sum + (it.qty || 0) : sum), 0);
      const discounts = sales.reduce((s, o:any) => s + (o.discount ?? 0), 0);
      const salesTotal = sales.reduce((s, o:any) => s + (o.total ?? 0), 0);

      const incomeTx = includeQuickTx ? txs.filter(t => t.kind === "income").reduce((s, t) => s + t.amount, 0) : 0;
      const expenseTx = includeQuickTx ? txs.filter(t => t.kind === "expense").reduce((s, t) => s + t.amount, 0) : 0;

      const income = salesTotal + incomeTx;
      const expense = expenseTx;
      const net = income - expense;
      const aov = orders ? income / orders : 0;

      return { date: d, income, expense, net, orders, items: itemsCount, discounts, aov };
    });
  }, [dates, txByDate, allSales, allItems, includeQuickTx]);

  const totals = useMemo(() => {
    const agg = daySeries.reduce((a, d) => {
      a.income += d.income; a.expense += d.expense; a.net += d.net;
      a.orders += d.orders; a.items += d.items; a.discounts += d.discounts;
      return a;
    }, { income:0, expense:0, net:0, orders:0, items:0, discounts:0 });
    const aov = agg.orders ? agg.income / agg.orders : 0;
    return { ...agg, aov };
  }, [daySeries]);

  /* -------- payment methods breakdown (sales + income tx) -------- */
  const methodBreakdown = useMemo(() => {
    const map: Record<string, number> = {};
    // sales revenue
    for (const s of allSales) {
      if (!dates.includes(s.sold_on)) continue;
      const k = (s.method || "—").toLowerCase();
      map[k] = (map[k] || 0) + (s.total ?? 0);
    }
    // quick income transactions (optional)
    if (includeQuickTx) {
      for (const d of dates) {
        for (const t of txByDate[d] || []) {
          if (t.kind !== "income") continue;
          const k = (t.method || "—").toLowerCase();
          map[k] = (map[k] || 0) + t.amount;
        }
      }
    }
    // sort
    return Object.entries(map).sort((a,b)=> b[1]-a[1]);
  }, [allSales, dates, txByDate, includeQuickTx]);

  /* -------- top products in range -------- */
  const topProducts = useMemo(() => {
    // find sale ids in range
    const dateSet = new Set(dates);
    const ids = new Set(allSales.filter(s => dateSet.has(s.sold_on)).map(s => s.id));
    const counts: Record<string, number> = {};
    for (const it of allItems) {
      if (!ids.has(it.sale_id)) continue;
      const name = (it as SaleItem).name_snapshot || "Unnamed";
      counts[name] = (counts[name] || 0) + (it.qty || 0);
    }
    return Object.entries(counts).sort((a,b)=> b[1]-a[1]).slice(0,10)
      .map(([name, qty]) => ({ name, qty }));
  }, [allItems, allSales, dates]);

  /* -------- day ledger (only when single day selected) -------- */
  const isSingleDay = range === "today";
  const ledgerRows = useMemo(() => {
    if (!isSingleDay) return [];
    const d = dayDate;
    const sales = allSales.filter(s => s.sold_on === d);
    const txs = txByDate[d] || [];
    const merged = [
      ...sales.map(s => ({ type: "sale" as const, at: s.created_at, sale: s })),
      ...txs.map(t => ({ type: "tx" as const, at: t.created_at, tx: t })),
    ];
    return merged.sort((a,b)=> (a.at||0) - (b.at||0));
  }, [isSingleDay, allSales, txByDate, dayDate]);

  /* -------- actions -------- */
  function togglePaid(id: string) { setPaidFlag(id, !paidMap[id]); refreshPaid(); }
  function removeTx(id: string) {
    if (!window.confirm("Delete this transaction?")) return;
    deleteTransaction(id); refreshPaid(); setPulse(p=>p+1);
  }
  function exportDailyCSV() {
    const rows: (string|number)[][] = [["Date","Orders","Items","Income","Expense","Net","AOV","Discounts"]];
    daySeries.forEach(d => rows.push([d.date,d.orders,d.items,d.income.toFixed(2),d.expense.toFixed(2),d.net.toFixed(2),d.aov.toFixed(2),d.discounts.toFixed(2)]));
    const label = range === "month" ? monthKey : range === "7d" ? `${addDays(dayDate,-6)}_to_${dayDate}` :
      range === "custom" ? `${startDate}_to_${endDate}` : dayDate;
    downloadCSV(`report-${label}.csv`, rows);
  }
  function exportLedgerCSV() {
    if (!isSingleDay) return;
    const rows: (string|number)[][] = [["Time","Kind","Amount","Description","Method/Ref"]];
    for (const r of ledgerRows) {
      if (r.type === "sale") {
        const s = r.sale!;
        rows.push([new Date(s.created_at).toLocaleTimeString(), "sale", (s.total ?? 0).toFixed(2),
          `Subtotal:${money(s.subtotal ?? 0)} Discount:${money(s.discount ?? 0)}`, s.method || "—"]);
      } else {
        const t = r.tx!;
        rows.push([new Date(t.created_at).toLocaleTimeString(), t.kind, t.amount.toFixed(2),
          t.description || "—", [t.method, t.reference].filter(Boolean).join(" • ") || "—"]);
      }
    }
    downloadCSV(`ledger-${dayDate}.csv`, rows);
  }

  /* -------- UI -------- */
  const title =
    range === "today" ? "Today" :
    range === "7d" ? "Last 7 Days" :
    range === "month" ? `Month (${monthKey})` :
    `Custom (${startDate} → ${endDate})`;

  return (
    <div className="grid gap-6">
      {/* Controls + KPIs */}
      <Card>
        <div className="flex flex-col gap-3 mb-3 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight">Reports</h1>
            <div className="text-sm muted">Deep-dive analytics and exports — more detail than the dashboard.</div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="segment">
              <input id="rg-today" type="radio" name="rg" checked={range==="today"} onChange={()=>setRange("today")} />
              <label htmlFor="rg-today">Today</label>
              <input id="rg-7d" type="radio" name="rg" checked={range==="7d"} onChange={()=>setRange("7d")} />
              <label htmlFor="rg-7d">7 Days</label>
              <input id="rg-month" type="radio" name="rg" checked={range==="month"} onChange={()=>setRange("month")} />
              <label htmlFor="rg-month">This Month</label>
              <input id="rg-custom" type="radio" name="rg" checked={range==="custom"} onChange={()=>setRange("custom")} />
              <label htmlFor="rg-custom">Custom</label>
            </div>

            {range === "today" && (
              <div className="flex items-center gap-2">
                <label className="label">Day</label>
                <input className="w-auto control" type="date" value={dayDate} onChange={e=>setDayDate(e.target.value || todayYMD())}/>
                <button className="btn-ghost" onClick={()=>setDayDate(todayYMD())}>Today</button>
              </div>
            )}

            {range === "month" && (
              <div className="flex items-center gap-2">
                <label className="label">Month</label>
                <input className="w-auto control" type="month" value={monthKey} onChange={e=>setMonthKey(e.target.value || monthKey)} />
              </div>
            )}

            {range === "custom" && (
              <div className="flex items-center gap-2">
                <label className="label">From</label>
                <input className="w-auto control" type="date" value={startDate} onChange={e=>setStartDate(e.target.value || startDate)} />
                <label className="label">To</label>
                <input className="w-auto control" type="date" value={endDate} onChange={e=>setEndDate(e.target.value || endDate)} />
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 mb-3">
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={includeQuickTx} onChange={e=>setIncludeQuickTx(e.target.checked)} />
            <span className="muted">Include Quick Transactions</span>
          </label>
          <button className="btn-ghost" onClick={exportDailyCSV}>Export {title} CSV</button>
          {isSingleDay && <button className="btn-ghost" onClick={exportLedgerCSV}>Export Day Ledger</button>}
        </div>

        <div className="grid gap-3 md:grid-cols-3 xl:grid-cols-7">
          <Pill label="Income"      value={money(totals.income)} color="ok" />
          <Pill label="Expenses"    value={money(totals.expense)} color="bad" />
          <Pill label="Net"         value={money(totals.net)} color={totals.net >= 0 ? "ok" : "bad"} />
          <Pill label="Orders"      value={String(totals.orders)} color="ok" />
          <Pill label="Items Sold"  value={String(totals.items)} color="ok" />
          <Pill label="AOV"         value={money(totals.aov)} color="ok" />
          <Pill label="Discounts"   value={money(totals.discounts)} color="bad" />
        </div>
      </Card>

      {/* Trends */}
      <Card>
        <h2 className="mb-3 text-lg font-bold">{title} — Trends</h2>
        <div className="grid gap-4 md:grid-cols-3">
          <div className="kpi-tile"><SparkBars series={daySeries.map(d=>Math.round(d.income))} title="Income" /></div>
          <div className="kpi-tile"><SparkBars series={daySeries.map(d=>Math.round(d.expense))} title="Expenses" /></div>
          <div className="kpi-tile"><SparkBars series={daySeries.map(d=>Math.round(d.net))} title="Net" /></div>
        </div>
        <div className="grid gap-4 mt-4 md:grid-cols-2">
          <div className="kpi-tile"><SparkBars series={daySeries.map(d=>d.orders)} title="Orders" /></div>
          <div className="kpi-tile"><SparkBars series={daySeries.map(d=>d.items)} title="Items Sold" /></div>
        </div>
      </Card>

      {/* Payment Methods + Top Products */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <h2 className="mb-3 text-lg font-bold">Payment Methods (Sales {includeQuickTx ? "+ Quick Income" : ""})</h2>
          {methodBreakdown.length === 0 ? (
            <div className="muted">No payments in this range.</div>
          ) : (
            <div className="overflow-auto">
              <table className="w-full border-collapse text-[0.95rem]">
                <thead className="sticky top-0 bg-[#0f1722]">
                  <tr className="text-left">
                    <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Method</th>
                    <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {methodBreakdown.map(([m, amt], i) => (
                    <tr key={m} className={`border-b border-[var(--line)]/40 ${i%2===0 ? "bg-[#0e1526]/30" : ""}`}>
                      <td className="px-3 py-2">{m.toUpperCase()}</td>
                      <td className="px-3 py-2 font-extrabold">{money(amt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <Card>
          <h2 className="mb-3 text-lg font-bold">Top Products</h2>
          {topProducts.length === 0 ? (
            <div className="muted">No sales in this range.</div>
          ) : (
            <div className="overflow-auto">
              <table className="w-full border-collapse text-[0.95rem]">
                <thead className="sticky top-0 bg-[#0f1722]">
                  <tr className="text-left">
                    <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Product</th>
                    <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Qty</th>
                  </tr>
                </thead>
                <tbody>
                  {topProducts.map((t, i) => (
                    <tr key={t.name} className={`border-b border-[var(--line)]/40 ${i%2===0 ? "bg-[#0e1526]/30" : ""}`}>
                      <td className="px-3 py-2">{t.name}</td>
                      <td className="px-3 py-2 font-extrabold">{t.qty}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>

      {/* Daily table (always) */}
      <Card>
        <h2 className="mb-3 text-lg font-bold">{title} — Daily Summary</h2>
        <div className="overflow-auto">
          <table className="w-full border-collapse text-[0.95rem]">
            <thead className="sticky top-0 bg-[#0f1722]">
              <tr className="text-left">
                <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Date</th>
                <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Orders</th>
                <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Items</th>
                <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Income</th>
                <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Expenses</th>
                <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Net</th>
                <th className="px-3 py-2 font-extrabold text-[var(--muted)]">AOV</th>
                <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Discounts</th>
              </tr>
            </thead>
            <tbody>
              {daySeries.map((d, i) => (
                <tr key={d.date} className={`border-b border-[var(--line)]/40 ${i%2===0 ? "bg-[#0e1526]/30" : ""}`}>
                  <td className="px-3 py-2 whitespace-nowrap">{d.date}</td>
                  <td className="px-3 py-2">{d.orders}</td>
                  <td className="px-3 py-2">{d.items}</td>
                  <td className="px-3 py-2 font-extrabold">{money(d.income)}</td>
                  <td className="px-3 py-2">{money(d.expense)}</td>
                  <td className="px-3 py-2">{money(d.net)}</td>
                  <td className="px-3 py-2">{money(d.aov)}</td>
                  <td className="px-3 py-2">{money(d.discounts)}</td>
                </tr>
              ))}
              {!daySeries.length && (
                <tr><td colSpan={8} className="px-3 py-3 text-center muted">No data in this range.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Day ledger with actions (only Today view) */}
      {isSingleDay && (
        <Card>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold">Day Ledger — {dayDate}</h2>
            <div className="badge">Realtime</div>
          </div>
          <div className="overflow-auto">
            <table className="w-full border-collapse text-[0.95rem]">
              <thead className="sticky top-0 bg-[#0f1722]">
                <tr className="text-left">
                  <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Time</th>
                  <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Type</th>
                  <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Amount</th>
                  <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Details</th>
                  <th className="px-3 py-2 font-extrabold text-[var(--muted)]">Method/Ref</th>
                  <th className="px-3 py-2"></th>
                </tr>
              </thead>
              <tbody>
                {ledgerRows.length === 0 ? (
                  <tr><td colSpan={6} className="px-3 py-3 text-center muted">No entries today.</td></tr>
                ) : ledgerRows.map((r, i) => {
                  if (r.type === "sale") {
                    const s:any = r.sale!;
                    return (
                      <tr key={`s-${s.id}`} className={`border-b border-[var(--line)]/40 ${i%2===0 ? "bg-[#0e1526]/30" : ""}`}>
                        <td className="px-3 py-2 whitespace-nowrap">{new Date(s.created_at).toLocaleTimeString()}</td>
                        <td className="px-3 py-2"><span className="tag">sale</span></td>
                        <td className="px-3 py-2 font-extrabold">{money(s.total ?? 0)}</td>
                        <td className="px-3 py-2">Subtotal {money(s.subtotal ?? 0)} • Discount {money(s.discount ?? 0)}</td>
                        <td className="px-3 py-2">{s.method || "—"}</td>
                        <td className="px-3 py-2">—</td>
                      </tr>
                    );
                  } else {
                    const t = r.tx!;
                    const paid = !!paidMap[t.id];
                    return (
                      <tr key={`t-${t.id}`} className={`border-b border-[var(--line)]/40 ${i%2===0 ? "bg-[#0e1526]/30" : ""}`}>
                        <td className="px-3 py-2 whitespace-nowrap">{new Date(t.created_at).toLocaleTimeString()}</td>
                        <td className="px-3 py-2">
                          <span className="tag">{t.kind}</span>{" "}
                          <span className={`tag ${paid ? "paid-pill" : "unpaid-pill"}`}>{paid ? "Paid" : "Unpaid"}</span>
                        </td>
                        <td className="px-3 py-2 font-extrabold">{money(t.amount)}</td>
                        <td className="px-3 py-2">{t.description || "—"}</td>
                        <td className="px-3 py-2">{[t.method, t.reference].filter(Boolean).join(" • ") || "—"}</td>
                        <td className="px-3 py-2">
                          <div className="flex flex-wrap gap-2">
                            <button className="btn-ghost" onClick={()=>togglePaid(t.id)}>{paid ? "Unmark" : "Mark Paid"}</button>
                            <button className="btn-ghost" onClick={()=>removeTx(t.id)}>Delete</button>
                          </div>
                        </td>
                      </tr>
                    );
                  }
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
