// src/features/auth/Register.tsx
import { useState } from "react";
import { createUser, setSession } from "../../index"; // your existing core user fns
import { importBackup } from "../../spCore";          // NEW
import { useNavigate } from "react-router-dom";

export default function Register() {
  const nav = useNavigate();
  const [username, setUsername] = useState("");
  const [pin, setPin] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  async function onCreateAdmin(e: React.FormEvent) {
    e.preventDefault();
    setErr(null); setMsg(null); setBusy(true);
    try {
      const u = await createUser(username.trim(), pin, "admin");
      setSession({ userId: u.id, signedAt: Date.now() });
      nav("/", { replace: true });
    } catch (e: any) {
      setErr(e?.message || "Failed");
    } finally { setBusy(false); }
  }

  async function onRestore(file: File) {
    setErr(null); setMsg(null);
    try {
      const text = await file.text();
      const pass = prompt("Enter backup passphrase");
      if (!pass) return;
      setBusy(true);
      await importBackup(text, pass, "replace");
      setMsg("Backup restored. Please create the first admin to continue.");
    } catch (e: any) {
      setErr(e?.message || "Restore failed");
    } finally { setBusy(false); }
  }

  return (
    <div className="min-h-[calc(100vh-56px)] px-4 py-10 flex items-start justify-center">
      <div className="w-full max-w-lg rounded-2xl bg-[#0f172a] border border-[#1f2742] p-6">
        <h1 className="text-xl font-bold text-slate-100">Create admin</h1>
        <p className="mb-4 text-sm text-slate-400">Set up the first account (admin).</p>

        <form onSubmit={onCreateAdmin} className="grid gap-3">
          <input
            value={username}
            onChange={(e)=>setUsername(e.target.value)}
            placeholder="e.g. admin"
            className="rounded-lg bg-[#0b1220] border border-[#1f2742] px-3 py-2 text-slate-100"
            required
          />
          <input
            type="password"
            value={pin}
            onChange={(e)=>setPin(e.target.value)}
            placeholder="••••"
            className="rounded-lg bg-[#0b1220] border border-[#1f2742] px-3 py-2 text-slate-100"
            required
            minLength={4}
          />
          {err && <div className="text-sm text-red-400">{err}</div>}
          {msg && <div className="text-sm text-emerald-400">{msg}</div>}
          <button
            type="submit"
            disabled={busy}
            className="w-full px-4 py-2 mt-1 font-medium rounded-xl bg-emerald-500 text-slate-900 disabled:opacity-60"
          >
            {busy ? "Working..." : "Create Admin"}
          </button>
        </form>

        <div className="mt-6 border-t border-[#1f2742] pt-4">
          <div className="mb-2 text-sm font-medium text-slate-300">Or restore from backup</div>
          <label className="inline-flex items-center gap-2 cursor-pointer">
            <input
              type="file"
              accept=".spbak,application/json"
              onChange={(e)=> e.target.files && e.target.files[0] && onRestore(e.target.files[0])}
              className="hidden"
            />
            <span className="rounded-xl px-4 py-2 bg-[#18233c] border border-[#253055] hover:bg-[#1b2946]">
              Choose .spbak file
            </span>
          </label>
          <p className="text-[11px] text-slate-400 mt-2">
            Backup files are encrypted with your passphrase. Restore replaces existing data on this device.
          </p>
        </div>
      </div>
    </div>
  );
}
