import { setLicense, markActive, markPastDue } from "../lib/license";
(window as any).spPlan = {
  set: (plan: any, status: any="active") => { setLicense({ plan, status, updatedAt: Date.now() } as any); location.reload(); },
  pastDue: (days=2) => { markPastDue(days); location.reload(); },
  active: (plan="small") => { markActive(plan as any); location.reload(); },
};
console.info("[spPlan] Ready. Try spPlan.set('free'), spPlan.active('small'), spPlan.pastDue(2).");
