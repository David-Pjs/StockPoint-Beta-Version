
// src/ui/PlanGate.tsx
import React from "react";
import { limits, isReadOnly, getLicense } from "../lib/license";

export function PlanGate(props: { kind: "product" | "user"; count: number; children: React.ReactNode }) {
  const { kind, count, children } = props;
  const lic  = getLicense();
  const cap  = limits()[kind === "product" ? "products" : "users"];
  const over = count >= cap;
  const ro   = isReadOnly();

  if (over || ro) {
    return (
      <div className="rounded-md border border-red-500/30 bg-red-500/10 p-4 text-red-300">
        <div className="font-semibold">
          {over ? `You’ve exceeded your ${lic.plan.toUpperCase()} plan (${kind} limit ${cap}).`
                : `Your subscription is past due. New ${kind}s are blocked.`}
        </div>
        <div className="mt-2 text-sm opacity-80">Please upgrade in Settings to continue.</div>
      </div>
    );
  }
  return <>{children}</>;
}
