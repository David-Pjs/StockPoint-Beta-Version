
// src/ui/PlanHUD.tsx
import React from "react";
import { getLicense, limits } from "../lib/license";

export function PlanHUD() {
  const lic = getLicense();
  const lim = limits();
  return (
    <div className="text-xs opacity-60">
      Plan: <span className="font-medium">{lic.plan}</span> — Products cap {lim.products}, Users cap {lim.users}
      {lic.status === "past_due" ? <span className="ml-2 text-amber-400">• past due</span> : null}
    </div>
  );
}
