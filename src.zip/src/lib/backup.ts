// Encrypted backup/restore for all StockPoint localStorage keys.

const BACKUP_NAME = (stamp = new Date()) =>
  `stockpoint-${stamp.toISOString().replace(/[:T]/g, "-").slice(0, 16)}.spbak`;

const ITERATIONS = 150_000; // PBKDF2 cost
const TEXT = new TextEncoder();
const BIN = new TextDecoder();

function shouldInclude(key: string) {
  if (!key.startsWith("sp_")) return false;
  return key !== "sp_session" && key !== "__sp_changed__";
}

// Collect → JSON string
function snapshot(): string {
  const data: Record<string, string> = {};
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i)!;
    if (shouldInclude(k)) {
      const v = localStorage.getItem(k);
      if (v != null) data[k] = v;
    }
  }
  return JSON.stringify({ v: 1, createdAt: Date.now(), data });
}

// Write keys back
function restoreFrom(json: string, mode: "replace" | "merge" = "replace") {
  const parsed = JSON.parse(json) as { v: number; data: Record<string, string> };
  const { data } = parsed;

  if (mode === "replace") {
    // Wipe **only** the app keys we manage.
    const toDelete: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i)!;
      if (shouldInclude(k)) toDelete.push(k);
    }
    toDelete.forEach(k => localStorage.removeItem(k));
  }

  for (const [k, v] of Object.entries<string>(data)) {
    localStorage.setItem(k, v);
  }
  try {
    localStorage.setItem("__sp_changed__", String(Date.now()));
  } catch {}
}

/* ---------- crypto helpers (PBKDF2 + AES-GCM) ---------- */

async function deriveKey(passphrase: string, salt: Uint8Array) {
  const material = await crypto.subtle.importKey(
    "raw",
    TEXT.encode(passphrase),
    "PBKDF2",
    false,
    ["deriveKey"]
  );
  // Pass the salt directly as BufferSource
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt: salt, iterations: ITERATIONS, hash: "SHA-256" },
    material,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

function toU8(input: ArrayBuffer | Uint8Array): Uint8Array {
  return input instanceof Uint8Array ? input : new Uint8Array(input);
}

const b64 = {
  enc: (buf: ArrayBuffer | Uint8Array) => {
    const u8 = toU8(buf);
    let s = "";
    for (let i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]);
    return btoa(s);
  },
  dec: (str: string) => {
    const bin = atob(str);
    const u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return u8;
  },
};

/* ---------- public API ---------- */

export async function exportBackup(passphrase: string): Promise<{ filename: string; blob: Blob }> {
  if (!passphrase || passphrase.length < 4) throw new Error("Passphrase required (≥4 chars).");

  const plain = TEXT.encode(snapshot());
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(passphrase, salt);
  const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plain);

  const payload = JSON.stringify({
    v: 1,
    alg: "PBKDF2-AES-GCM",
    kdf: { iterations: ITERATIONS, salt: b64.enc(salt) },
    iv: b64.enc(iv),
    cipher: b64.enc(cipher),
  });

  return { filename: BACKUP_NAME(), blob: new Blob([payload], { type: "application/octet-stream" }) };
}

export async function importBackup(
  file: File,
  passphrase: string,
  mode: "replace" | "merge" = "replace"
) {
  if (!file) throw new Error("Select a .spbak file.");
  if (!passphrase || passphrase.length < 4) throw new Error("Passphrase required.");

  const text = await file.text();
  const obj = JSON.parse(text);

  if (!obj || obj.v !== 1 || obj.alg !== "PBKDF2-AES-GCM") {
    throw new Error("Invalid backup file.");
  }

  const salt = b64.dec(obj.kdf?.salt || "");
  const iv = b64.dec(obj.iv || "");
  const key = await deriveKey(passphrase, salt);

  let plain: ArrayBuffer;
  try {
    plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, b64.dec(obj.cipher));
  } catch {
    throw new Error("Wrong passphrase.");
  }

  restoreFrom(BIN.decode(new Uint8Array(plain)), mode);
}
