
// src/safe/IndexProductsFix.ts
// Paste these in your src/index.ts to replace the broken section around addProduct / updateProductQty.
import { readJSON, writeJSON, signalChange, KEYS } from "../index"; // adjust if paths differ
import { Product, MiniUser } from "../types/product";
import { assertCanMutateOrThrow, assertWithinLimitOrThrow } from "../lib/license";
import { getCurrentUser } from "../app/currentUser"; // adjust if you keep user util elsewhere

export function getProducts(): Product[] {
  return readJSON<Product[]>(KEYS.products, []);
}

export function saveProducts(list: Product[]): void {
  writeJSON(KEYS.products, list);
  signalChange();
}

export function addProduct(prod: Product): Product {
  const list = getProducts();

  assertCanMutateOrThrow("product");
  assertWithinLimitOrThrow("product", list.length);

  const u = getCurrentUser && getCurrentUser();
  const normalized: Product = {
    ...prod,
    cost: Number(prod.cost ?? 0),
    sell: Number(prod.sell ?? 0),
    stock_qty: Number(prod.stock_qty ?? 0),
    createdBy: u ? { id: u.id, username: u.username, role: u.role, photoUrl: u.photoUrl } : null,
    createdAt: Date.now(),
    id: crypto?.randomUUID ? crypto.randomUUID() : String(Date.now())
  };

  list.push(normalized);
  saveProducts(list);
  return normalized;
}

export function updateProductQty(productId: string, delta: number): void {
  const list = getProducts();
  const idx = list.findIndex(p => p.id === productId);
  if (idx === -1) return;
  const next = { ...list[idx], stock_qty: Number(list[idx].stock_qty ?? 0) + Number(delta ?? 0) };
  list[idx] = next;
  saveProducts(list);
}
